<?php
require_once('Location.php');
$lc=new Location();
$lc->insert($_POST['locC'],$_POST['locV'],$_POST['nbJ'],$_POST['date']);
header('Location:../view/listeLocation.php');
