<?php
include_once("../model/Modele.php");
class Voiture extends Modele
{
    public $idVoit, $numSerie, $marque, $carburant, $prixLocation;
    function __construct($id = "", $numSerie = "", $marque = "", $carburant = "", $prixLocation = "")
    {
        $this->idVoit = $id;
        $this->numSerie = $numSerie;
        $this->marque = $marque;
        $this->carburant = $carburant;
        $this->prixLocation = $prixLocation;
        parent::__construct();
    }
    function insert($numSerie, $marque, $carburant, $prixLocation)
    {
        $query = "insert into voiture(numSerie,marque,carburant,prixLocation) values (?, ?, ?, ?)";
        $res = $this->pdo->prepare($query);
        return $res->execute(array($numSerie, $marque, $carburant, $prixLocation));
    }
    function delete($idVoit)
    {
        $query = "delete from voiture where idVoiture=?";
        $res = $this->pdo->prepare($query);
        return $res->execute(array($idVoit));
    }
    function liste()
    {
        $query = "select * from voiture";
        $res = $this->pdo->prepare($query);
        $res->execute();
        return $res;
    }
    function rechercher($voit)
    {
        if ($voit == "Essence") {
            $query = "select * from voiture where carburant='$voit'";
        } else{
            $query = "select * from voiture where carburant='$voit'";
        }
        $res = $this->pdo->prepare($query);
        $res->execute();
        return $res;
    }
}
