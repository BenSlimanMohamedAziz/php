<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">
    <title>Liste Clients</title>
    <link rel="stylesheet" href="../css/liste.css">
</head>

<body>
    <center>
        <h1>Liste Clients : </h1>
        <form name='f' action='../Controller/suppClient.php' method='post'>
            <table border='2' class='styled-table'>
                <thead>
                    <tr>
                        <td></td>
                        <th>Identifiant : </th>
                        <th>Numéro CIN : </th>
                        <th>Nom : </th>
                        <th>Prénom : </th>
                        <th>Téléphone : </th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                    require_once('../Controller/Client.php');
                    $cl = new Client();
                    $res = $cl->liste();
                    foreach ($res as $row) {
                        echo "<tr>
                    <th><input type='radio' name='r' value=$row[idClient] required></th>
                        <th>$row[idClient]</th>
                         <th>$row[ncin]</th>
                            <th>$row[nom]</th>
                               <th>$row[prenom]</th>
                                    <th>$row[Telephone]</th></tr>";
                    }
                    ?>
                </tbody>
            </table>
            <br>
            <input type='submit' name='supp' value='Supprimer'>
           <a href="ajoutClient.php"><button type='button'>Ajouter un Client</button></a>
           <a href="home.html"><button type='button'>Accueil</button></a>
        </form>
    </center>

</body>

</html>