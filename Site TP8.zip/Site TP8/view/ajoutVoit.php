<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">
    <title>Ajouter Voiture</title>
    <link rel="stylesheet" href="../css/pages.css">
</head>

<body>
<center>
    <h1>Ajouter Voiture :</h1>
    <fieldset>
        <legend>Nouvelle Voiture :</legend>
        <form name="form" method="Post" action="../Controller/ajoutVoit_action.php">
            <br>
            <table class="tabform">
                <tr>
                    <td>Numéro serie : </td>
                    <td><input type="text" name="numserie" id='numserie' required></td>
                </tr>
                <tr>
                    <td>Marque : </td>
                    <td><input type="text" name="marvoit" id='marvoit' required></td>
                </tr>
                <tr>
                    <td>Carburant : </td>
                    <td><input type="text" name="carbu" id='carbu' required></td>
                </tr>
                <tr>
                    <td>Prix Location : </td>
                    <td><input type="text" name="prixloc" id='prixloc' required></td>
                </tr>
                <tr><th colspan="2">
                    <br>
                    <input type="submit" name="submit" value="Enregistrer">
                    <a href="home.html"><button type="button" name="annuler">Annuler</button></a>
                </tr>
            </table>
        </form>
    </fieldset>
</center>
</body>

</html>