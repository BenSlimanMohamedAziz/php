<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">
    <title>Ajouter Location</title>
    <link rel="stylesheet" href="../css/pages.css">
</head>

<body>
<center>
    <h1>Ajouter Location :</h1>
    <?php
    require_once('../Controller/Client.php');
    require_once('../Controller/Voiture.php');
    $cl = new Client();
    $vt = new Voiture();
    $res = $cl->liste();
    $res2 = $vt->liste();
    ?>
    <fieldset>
        <legend>Nouvelle Location :</legend>
        <form name="form" method="Post" action="../Controller/ajouterLoc_action.php">
            <br>
            <table class="tabform">
                <tr>
                    <td>Client : </td>
                    <td>
                        <select name="locC" id="locC" required>
                            <option value="0" selected disabled>- Sélectioner un Client -</option>
                            <?php
                            if ($res->rowCount() > 0) {
                                foreach ($res as $row) {
                                    echo "<option value='$row[idClient]'>$row[prenom]" . ' ' . "$row[nom]</option>";
                                }
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Marque : </td>
                    <td>
                        <select name="locV" id="locV" required>
                            <option value="0" selected disabled>- Sélectioner la Voiture -</option>
                            <?php
                            if ($res2->rowCount() > 0) {
                                foreach ($res2 as $row) {
                                    echo "<option value='$row[idVoiture]'>$row[marque]" . ' (' . "$row[numSerie]" . ')' . "</option>";
                                }
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Date : </td>
                    <td><input type="date" name="date" id='date' required></td>
                </tr>
                <tr>
                    <td>Nombre Jours : </td>
                    <td><input type="text" name="nbJ" id='nbJ' required></td>
                </tr>
                <tr>
                    <th colspan="2">
                        <br>
                        <input type="submit" name="submit" value="Valider">
                        <a href="home.html"><button type="button" name="annuler">Annuler</button></a>
                    </th>
                </tr>
            </table>
        </form>
    </fieldset>
</center>
</body>

</html>